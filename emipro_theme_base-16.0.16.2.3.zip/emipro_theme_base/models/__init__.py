# -*- coding: utf-8 -*-
from . import product_public_category
from . import website_menu
from . import website
from . import product_template
from . import product_product
from . import synonym_group
from . import search_keyword_report
from . import product_label
from . import product_attribute
from . import product_tab_line
from . import ir_attachment
from . import product_brand
from . import website_snippet_filter
from . import menu_label
from . import proudct_pricelist
# from . import sale_order
