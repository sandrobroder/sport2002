# See LICENSE file for full copyright and licensing details.

from . import dynamic_label
